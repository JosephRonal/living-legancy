import MintBg from "../../assets/img/Mint.png";
import IconBg from "../../assets/img/icon-bg.png";
import MintIcon from "../../assets/img/mint-icon.png";
import StakeIcon from "../../assets/img/stake-icon.png";
import MarketIcon from "../../assets/img/marketplace-icon.png";
import Line from "../../assets/img/Line 1.png";
import Logo from "../../assets/img/dragu-logo.png";
import Minus from "../../assets/img/minus.png";
import Plus from "../../assets/img/plus.png";
import Card1 from "../../assets/img/card1.png";
import Card2 from "../../assets/img/card2.png";
import Card3 from "../../assets/img/card3.png";
import Card4 from "../../assets/img/card4.png";
import Card5 from "../../assets/img/card5.png";
import Card6 from "../../assets/img/card6.png";
import Card7 from "../../assets/img/card7.png";
import Card8 from "../../assets/img/card8.png";
import Plnt from "../../assets/img/plnt.png";
import LockIcon from "../../assets/img/lock.png";
import Cross from "../../assets/img/cross.png";
///////////////////////////////////////////////////// Collection Images
export {
  MintBg,
  IconBg,
  MintIcon,
  StakeIcon,
  MarketIcon,
  Line,
  Logo,
  Minus,
  Plus,
  Card1,
  Card2,
  Card3,
  Card4,
  Card5,
  Card6,
  Card7,
  Card8,
  LockIcon,
  Plnt,
  Cross,
};
